## ----setup, echo=FALSE, message=FALSE------------------------------------
#setwd('/Users/jeanette/Dropbox/School/PhD/HIV_WA/public/package1.0/HIVBackCalc')

# Setup
#load('data/KCsim.RData')
library(HIVBackCalc)
#source('R/model.R')
#source('R/tid.R')
#source('R/results.R')
#library(reshape2)
#library(ggplot2)
#library(scales)
#library(Hmisc)
#library(plyr)

## ----, echo=TRUE---------------------------------------------------------
data(KCsim)

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  head(KCsim)

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(head(KCsim))

## ----, echo=TRUE, results='asis'-----------------------------------------
diagInterval = 0.25

## ----, echo=TRUE, results='asis'-----------------------------------------
TIDs <- estimateTID(KCsim$infPeriod, intLength=diagInterval)

## ----, echo=TRUE, results='asis', fig.height=5, fig.width=6.5------------
plot(TIDs, intLength=diagInterval, 
     cases = c('Base Case', 'Upper Bound'))

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  summary(TIDs, intLength=diagInterval,
#          cases = c('Base Case', 'Upper Bound'),
#          times =c(0, 0.25, 1, 5, 10, 18))

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(summary(TIDs, intLength=diagInterval,
                     cases = c('Base Case', 'Upper Bound'),
                     times =c(0, 0.25, 1, 5, 10, 18)))

## ----, echo=TRUE, results='asis'-----------------------------------------
diagCounts = tabulateDiagnoses(KCsim, intLength=diagInterval)

## ----, echo=TRUE, results='asis', cache=TRUE-----------------------------
incidenceBase = estimateIncidence(y=diagCounts,
                                  pid=TIDs[['base_case']]$pdffxn,
                                  gamma=0.1,
                                  verbose=FALSE)
incidenceUpper = estimateIncidence(y=diagCounts,
                                  pid=TIDs[['upper_bound']]$pdffxn,
                                  gamma=0.1,
                                  verbose=FALSE)

## ----, echo=TRUE, fig.show="hold", fig.width=5, fig.height=5, out.width="325px"----
plot(incidenceBase, case='Base Case')
plot(incidenceUpper, case='Upper Bound')

## ----, echo=TRUE, eval=TRUE----------------------------------------------
# Base Case
undiagnosedBase <- estimateUndiagnosed(incidenceBase)
# Upper Bound
undiagnosedUpper <- estimateUndiagnosed(incidenceUpper)

## ----, echo=TRUE, eval=TRUE----------------------------------------------
results <- combineResults(list(`Base Case`=list(incidenceBase,
                                            undiagnosedBase),
                             `Upper Bound`=list(incidenceUpper,
                                              undiagnosedUpper)))

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  results$resultsSummary

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(results$resultsSummary)

## ----, echo=TRUE, eval=TRUE, fig.width=6, fig.height=5, fig.align='center'----
plot(results)

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(head(mtcars, 10))

