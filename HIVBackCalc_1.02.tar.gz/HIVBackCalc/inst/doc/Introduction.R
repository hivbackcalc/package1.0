## ----setup, echo=FALSE, message=FALSE------------------------------------

# Setup
library(HIVBackCalc)
#source('R/model.R')
#source('R/tid.R')
#source('R/results.R')
#library(reshape2)
#library(ggplot2)
#library(scales)
#library(Hmisc)
#library(plyr)

## ----, echo=TRUE---------------------------------------------------------
data(KCsim)

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  head(KCsim)

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(head(KCsim))

## ----, echo=TRUE, results='asis'-----------------------------------------
diagInterval = 0.25

## ----, echo=TRUE, results='asis'-----------------------------------------
TIDs <- estimateTID(KCsim$infPeriod, intLength=diagInterval)

## ----, echo=TRUE, results='asis', fig.height=5, fig.width=6.5------------
plot(TIDs, intLength=diagInterval, 
     cases = c('Base Case', 'Upper Bound'))

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  summary(TIDs, intLength=diagInterval,
#          cases = c('Base Case', 'Upper Bound'),
#          times =c(0, 0.25, 1, 5, 10, 18))

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(summary(TIDs, intLength=diagInterval,
                     cases = c('Base Case', 'Upper Bound'),
                     times =c(0, 0.25, 1, 5, 10, 17, 18)))

## ----, echo=TRUE, results='asis'-----------------------------------------
diagCounts = tabulateDiagnoses(KCsim, intLength=diagInterval)

## ----, echo=TRUE, fig.show="hold", fig.width=5, fig.height=5, out.width="325px"----
plot(incidenceBase, case='Base Case')
plot(incidenceUpper, case='Upper Bound')

## ----, echo=TRUE, eval=TRUE----------------------------------------------
# Base Case
undiagnosedBase <- estimateUndiagnosed(incidenceBase)
# Upper Bound
undiagnosedUpper <- estimateUndiagnosed(incidenceUpper)

## ----, echo=TRUE, eval=TRUE----------------------------------------------
results <- combineResults(list(`Base Case`=list(incidenceBase,
                                            undiagnosedBase),
                             `Upper Bound`=list(incidenceUpper,
                                              undiagnosedUpper)))

## ----, echo=TRUE, eval=FALSE---------------------------------------------
#  results$resultsSummary

## ----, echo=FALSE, results='asis'----------------------------------------
knitr::kable(results$resultsSummary)

## ----, echo=TRUE, eval=TRUE, fig.width=6, fig.height=5, fig.align='center'----
plot(results)

## ----, echo=TRUE---------------------------------------------------------
constantIncidence <- mean(diagCounts, na.rm=TRUE)

## ----, echo=TRUE, eval=TRUE----------------------------------------------
# Base Case
undiagnosedConstBase <- estimateUndiagnosedConst(infPeriod=KCsim$infPeriod,
                                                 case='base_case',
                                                 intLength=diagInterval,
                                                 incidence=constantIncidence)

# Upper Bound
undiagnosedConstUpper <- estimateUndiagnosedConst(infPeriod=KCsim$infPeriod,
                                                  case='upper_bound',
                                                  intLength=diagInterval,
                                                  incidence=constantIncidence)


rbind(BaseCase=undiagnosedConstBase, 
      UpperBound=undiagnosedConstUpper)

## ----, echo=F------------------------------------------------------------
cat("Comparing whether last negative test exists")
rbind(before=table(KCsim$everHadNegTest, useNA="always"), 
      after=table(KCsim$everHadNegTestM, useNA="always"))

cat("Comparing length of possible infection window (years)")
rbind(before=table(round(KCsim$infPeriod,0), useNA="always"), 
      after=table(round(KCsim$infPeriodM,0), useNA="always"))

## ----, echo=TRUE, eval=TRUE----------------------------------------------
constantIncidence <- mean(diagCounts, na.rm=TRUE)
 
# Base Case
undiagnosedConstBaseM <- estimateUndiagnosedConst(infPeriod=KCsim$infPeriodM,
                                                 case='base_case',
                                                 intLength=diagInterval,
                                                 incidence=constantIncidence)

# Upper Bound
undiagnosedConstUpperM <- estimateUndiagnosedConst(infPeriod=KCsim$infPeriodM,
                                                  case='upper_bound',
                                                  intLength=diagInterval,
                                                  incidence=constantIncidence)


## ----, echo=FALSE--------------------------------------------------------
cat("Compare resulting estimates of the number of undiagnosed cases")
rbind(before=round(c(BaseCase=undiagnosedConstBase, UpperBound=undiagnosedConstUpper),0),
      after=round(c(undiagnosedConstBaseM, undiagnosedConstUpperM),0),
      ratio=round(c(undiagnosedConstBaseM/undiagnosedConstBase, 
                    undiagnosedConstUpperM/undiagnosedConstUpper),1))


